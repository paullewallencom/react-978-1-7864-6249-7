import React from 'react';
import ReactDOM from 'react-dom';

module.exports.NoMatch = React.createClass({
  render: function() {
    return (<h1>URL not Found</h1>);
  }
});