import React from 'react';
import ReactDOM from 'react-dom';

module.exports.Profile = React.createClass({
  render: function() {
    return (<h1>Profile Page</h1>);
  }
});