export default {
  appId: '1362753213759665',
  cookie: true,
  xfbml: false,
  version: 'v2.5'
};
