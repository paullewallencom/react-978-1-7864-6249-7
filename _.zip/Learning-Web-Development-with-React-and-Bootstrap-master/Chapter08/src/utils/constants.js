export const POST = 'POST';
export const LIKE = 'LIKE';
export const COMMENT = 'COMMENT';
export const POST_POINT = 3;
export const COMMENT_POINT = 2;
export const LIKE_POINT = 1;
export const MAX_OUTPUT = 25;
export const facebookBlue = 'rgb(58, 87, 149)';
